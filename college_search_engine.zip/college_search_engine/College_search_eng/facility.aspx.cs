﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class facility : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1submit_Click(object sender, EventArgs e)
    {
        try
        {
            HttpPostedFile postedfle = FileUpload1.PostedFile;
            string imgname = Path.GetFileName(postedfle.FileName);
            Stream str = postedfle.InputStream;
            BinaryReader binaryrd = new BinaryReader(str);
            byte[] bytes = binaryrd.ReadBytes((int)str.Length);
            SqlCommand cmd;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["college_search_engineConnectionString"].ConnectionString);
            con.Open();
            String insertqr = "insert into facility(college_id,name,description,facility_image)values(@college_id,@name,@decsription,@facility_image)";
            cmd = new SqlCommand(insertqr, con);
            cmd.Parameters.AddWithValue("@college_id", DropDownList1.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@name", TextBox1name.Text);
            cmd.Parameters.AddWithValue("@decsription", TextBox3description.Text);
            cmd.Parameters.AddWithValue("@facility_image", bytes);


            cmd.ExecuteNonQuery();
            con.Close();
            msg.Text = "values are inserted";
            //TextBox1collegeid.Text = "";
            TextBox1name.Text = "";
            TextBox3description.Text = "";
            //TextBox4facilityimage.Text = "";

        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }

    protected void cancel_Click(object sender, EventArgs e)
    {
        msg.Text = "";
        //TextBox1collegeid.Text = "";
        TextBox1name.Text = "";
        TextBox3description.Text = "";
        //TextBox4facilityimage.Text = "";
    }
    protected void Button3view_Click(object sender, EventArgs e)
    {
        Response.Redirect("facility_view.aspx");
    }
}