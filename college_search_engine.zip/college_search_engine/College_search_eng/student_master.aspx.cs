﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class student_master : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void submit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["college_search_engineConnectionString"].ConnectionString);
            con.Open();
            String insertqr = "insert into student_master(f_name,l_name,address,dob,age,gender,caste,categories,email_id,u_name)values(@f_name,@l_name,@address,@dob,@age,@gender,@caste,@categories,@email_id,@u_name)";
            cmd = new SqlCommand(insertqr, con);

            cmd.Parameters.AddWithValue("@f_name", TextBox1firstname.Text);
            cmd.Parameters.AddWithValue("@l_name", TextBox2lastname.Text);
            cmd.Parameters.AddWithValue("@address", TextBox3address.Text);
            cmd.Parameters.AddWithValue("@dob", TextBox4dob.Text);
            cmd.Parameters.AddWithValue("@age", TextBox5age.Text);
            cmd.Parameters.AddWithValue("@gender", TextBox6gender.Text);
            cmd.Parameters.AddWithValue("@caste", TextBox7caste.Text);
            cmd.Parameters.AddWithValue("@categories", TextBox8categories.Text);
            cmd.Parameters.AddWithValue("@email_id", TextBox9emailid.Text);
           //cmd.Parameters.AddWithValue("@photo", TextBox10photo.Text);
            cmd.Parameters.AddWithValue("@u_name", TextBox11username.Text);




            cmd.ExecuteNonQuery();
            con.Close();
            SqlCommand cmd2;
            con.Open();
            string query = "insert into login(u_name,password)values(@u_name,@password)";
            cmd2 = new SqlCommand(query,con);
            cmd2.Parameters.AddWithValue("@u_name", TextBox11username.Text);
            cmd2.Parameters.AddWithValue("@password",TextBox9emailid.Text);
            cmd2.ExecuteNonQuery();
            con.Close();
            msg.Text = "values are inserted";
            Label1.Text = "user name is:" + TextBox11username.Text;
            Label2.Text = "Password is:" + TextBox9emailid.Text;
            msg.Visible = true;
            Label1.Visible = true;
            Label2.Visible = true;
            TextBox1firstname.Text = "";
            TextBox2lastname.Text = "";
            TextBox3address.Text = "";
            TextBox4dob.Text = "";
            TextBox5age.Text = "";
            TextBox6gender.Text = "";
            TextBox7caste.Text = "";
            TextBox8categories.Text = "";
            TextBox9emailid.Text = "";
            //TextBox10photo.Text = "";
            TextBox11username.Text = "";


        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void cancel_Click(object sender, EventArgs e)
    {
        msg.Text = "";
        TextBox1firstname.Text = "";
        TextBox2lastname.Text = "";
        TextBox3address.Text = "";
        TextBox4dob.Text = "";
        TextBox5age.Text = "";
        TextBox6gender.Text = "";
        TextBox7caste.Text = "";
        TextBox8categories.Text = "";
        TextBox9emailid.Text = "";
       // TextBox10photo.Text = "";
        TextBox11username.Text = "";
        Response.Redirect("mainhome.aspx");
    }
   
}