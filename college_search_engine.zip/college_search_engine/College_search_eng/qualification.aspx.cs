﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class qualification : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1submit_Click(object sender, EventArgs e)
    {
         try
        {
            SqlCommand cmd;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["college_search_engineConnectionString"].ConnectionString);
            con.Open();
            String insertqr = "insert into qualification(stud_id,qual_name,university_name,year_of_passing,marks,total_marks,percentage)values(@stud_id,@qual_name,@university_name,@year_of_passing,@marks,@total_marks,@percentage)";
            cmd = new SqlCommand(insertqr, con);

            cmd.Parameters.AddWithValue("@stud_id", TextBox1studentid.Text);
            cmd.Parameters.AddWithValue("@qual_name", TextBox2qualname.Text);
            cmd.Parameters.AddWithValue("@university_name", TextBox3universityname.Text);
            cmd.Parameters.AddWithValue("@year_of_passing", TextBox4yearofpass.Text);
           cmd.Parameters.AddWithValue("@marks", TextBox5marks.Text);
           cmd.Parameters.AddWithValue("@total_marks", TextBox6totalmarks.Text);
           cmd.Parameters.AddWithValue("@percentage", TextBox7percentage.Text);



            cmd.ExecuteNonQuery();
            con.Close();
            msg.Text = "values are inserted";
            TextBox1studentid.Text = "";
            TextBox2qualname.Text = "";
            TextBox3universityname.Text = "";
            TextBox4yearofpass.Text = "";
             TextBox5marks.Text="";
              TextBox6totalmarks.Text="";
             TextBox7percentage.Text="";
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }

    protected void  Button2cancel_Click(object sender, EventArgs e)
{
         msg.Text = "";
        TextBox1studentid.Text = "";
            TextBox2qualname.Text = "";
            TextBox3universityname.Text = "";
            TextBox4yearofpass.Text = "";
             TextBox5marks.Text="";
              TextBox6totalmarks.Text="";
             TextBox7percentage.Text="";
}
protected void  Button3view_Click(object sender, EventArgs e)
{
    Response.Redirect("qualification_view.aspx");
}
}
