﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class college_master : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void sumit_Click(object sender, EventArgs e)
    {
        try
        {
            HttpPostedFile postedfle = FileUpload1.PostedFile;
            string imgname = Path.GetFileName(postedfle.FileName);
            Stream str = postedfle.InputStream;
            BinaryReader binaryrd = new BinaryReader(str);
            byte[] bytes = binaryrd.ReadBytes((int)str.Length);
            SqlCommand cmd;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["college_search_engineConnectionString"].ConnectionString);
            con.Open();
            String insertqr = "insert into college_master(college_code,college_name,college_desc,address,contact_person,contact_no,prospectus,image)values(@college_code,@college_name,@college_desc,@address,@contact_person,@contact_no,@prospectus,@image)";
            cmd = new SqlCommand(insertqr, con);
            cmd.Parameters.AddWithValue("@college_code", TextBox1collegecode.Text);
            cmd.Parameters.AddWithValue("@college_name", TextBox2collegename.Text);
            cmd.Parameters.AddWithValue("@college_desc", TextBox3collegedesc.Text);
            cmd.Parameters.AddWithValue("@address", TextBox1address.Text);
            cmd.Parameters.AddWithValue("@contact_person", TextBox5contactperson.Text);
            cmd.Parameters.AddWithValue("@contact_no", TextBox6contactno.Text);
            cmd.Parameters.AddWithValue("@prospectus", TextBox7prospectus.Text);
            cmd.Parameters.AddWithValue("@image",bytes);
            cmd.ExecuteNonQuery();
            con.Close();
            msg.Text = "values are inserted";
            TextBox1collegecode.Text = "";
            TextBox2collegename.Text = "";
            TextBox3collegedesc.Text = "";
            TextBox1address.Text = "";
            TextBox5contactperson.Text = "";
            TextBox6contactno.Text = "";
            TextBox7prospectus.Text = "";
            //TextBox8image.Text = "";


        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void cancel_Click(object sender, EventArgs e)
    {

        msg.Text = "";
        TextBox1collegecode.Text = "";
        TextBox2collegename.Text = "";
        TextBox3collegedesc.Text = "";
        TextBox1address.Text = "";
        TextBox5contactperson.Text = "";
        TextBox6contactno.Text = "";
        TextBox7prospectus.Text = "";
        //TextBox8image.Text = "";

    }
    protected void view_Click(object sender, EventArgs e)
    {
        Response.Redirect("college_master_view.aspx");
    }
}