﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class student_application : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1submit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["college_search_engineConnectionString"].ConnectionString);
            con.Open();
            String insertqr = "insert into Student_application(student_id,course_id,college_id,status,application_date)values(@student_id,@course_id,@college_id,@status,@application_date)";
            cmd = new SqlCommand(insertqr, con);
            cmd.Parameters.AddWithValue("@student_id", DropDownList1.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@course_id", DropDownList2.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@college_id", DropDownList3.SelectedItem.Value);
            cmd.Parameters.AddWithValue("@status", "new");
            cmd.Parameters.AddWithValue("@application_date", TextBox5appdate.Text);


            cmd.ExecuteNonQuery();
            con.Close();
            msg.Text = "values are inserted";
            //TextBox1studentid.Text = "";
            //TextBox2courseid.Text = "";
            //TextBox3collegeid.Text = "";
            //TextBox4status.Text = "";
            TextBox5appdate.Text = "";
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void Button2cancel_Click(object sender, EventArgs e)
    {
        msg.Text = "";
        //TextBox1studentid.Text = "";
        //TextBox2courseid.Text = "";
        //TextBox3collegeid.Text = "";
        //TextBox4status.Text = "";
        TextBox5appdate.Text = "";
    }
}