﻿
Partial Class course_master_view
    Inherits System.Web.UI.Page

End Class
