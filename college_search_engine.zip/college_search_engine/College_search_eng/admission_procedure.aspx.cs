﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class admission_procedure : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1submit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["college_search_engineConnectionString"].ConnectionString);
            con.Open();
            String insertqr = "insert into admission_procedure(course_id,description)values(@course_id,@description)";
            cmd = new SqlCommand(insertqr, con);
            cmd.Parameters.AddWithValue("@course_id", TextBox1courseid.Text);
            cmd.Parameters.AddWithValue("@description", description.Text);

            cmd.ExecuteNonQuery();
            con.Close();
            msg.Text = "values are inserted";
            TextBox1courseid.Text = "";
            description.Text = "";


        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void cancel_Click(object sender, EventArgs e)
    {
        msg.Text="";
        TextBox1courseid.Text = "";
        description.Text = "";

    }
    protected void Button3viewtable_Click(object sender, EventArgs e)
    {
        Response.Redirect("admission_procedure_view.aspx");
    }
}