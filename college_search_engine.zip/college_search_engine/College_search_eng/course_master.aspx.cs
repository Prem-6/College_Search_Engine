﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class course_master : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1submit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["college_search_engineConnectionString"].ConnectionString);
            con.Open();
            String insertqr = "insert into course_master(course_name,course_desc,duration)values(@course_name,@course_desc,@duration)";
            cmd = new SqlCommand(insertqr, con);
            cmd.Parameters.AddWithValue("@course_name", TextBox1coursename.Text);
            cmd.Parameters.AddWithValue("@course_desc", TextBox2coursedesc.Text);
            cmd.Parameters.AddWithValue("@duration", TextBox3duration.Text);


            cmd.ExecuteNonQuery();
            con.Close();
            msg.Text = "values are inserted";
            TextBox1coursename.Text = "";
            TextBox2coursedesc.Text = "";
            TextBox3duration.Text = "";

        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void Button2cancel_Click(object sender, EventArgs e)
    {
        msg.Text = "";
        TextBox1coursename.Text = "";
        TextBox2coursedesc.Text = "";
        TextBox3duration.Text = "";
    }
    protected void Button3view_Click(object sender, EventArgs e)
    {
        Response.Redirect("course_master_view.aspx");
    }
}